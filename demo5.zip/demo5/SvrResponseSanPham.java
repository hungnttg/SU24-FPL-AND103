package com.hnq40.firebaseexam1.demo5;

public class SvrResponseSanPham {
    //ket qua server tra ve
    private SanPham sanphams;
    private String message;

    public SanPham getSanphams() {
        return sanphams;
    }

    public String getMessage() {
        return message;
    }
}
